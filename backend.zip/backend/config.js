export const PORT =5555;
export const mongoDBURL = "mongodb+srv://root:root@task-management.f4ofvma.mongodb.net/tasks-collection1?retryWrites=true&w=majority&appName=Task-Management";


//export const mongoDBURL = "mongodb+srv://root:root@task-management-app.rhpxghq.mongodb.net/tasks-collection?appName=Task-Management-App";