import React from 'react'

const Nodatafound = () => {
  return (
    <div className='text-3xl my-8' >
        No data Found 
    </div>
  )
}

export default Nodatafound