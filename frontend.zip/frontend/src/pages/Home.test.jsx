
/* import '@testing-library/jest-dom'
import { render, screen } from "@testing-library/react"
import { Home } from "./Home"
import {act} from 'react';



test('Home renderss - correctly',() =>{
    render( <Home />)
    const textElementsOne = screen.getByText('Tasks List')
    expect(textElementsOne).toBeInTheDocument();
})


 test.only('Home renders with a name', () => {clea
   render(<Home name = "Tasks"/>)
   const textElementsTwo = screen.getByText('Task Table')
    expect(textElementsTwo).toBeInTheDocument();

})  */